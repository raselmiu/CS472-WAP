module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "asdfg123",
    DB: "dictionary"
  };